

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


SET SESSION AUTHORIZATION DEFAULT;

ALTER TABLE public.builds DISABLE TRIGGER ALL;



ALTER TABLE public.builds ENABLE TRIGGER ALL;


ALTER TABLE public.spells DISABLE TRIGGER ALL;



ALTER TABLE public.spells ENABLE TRIGGER ALL;


ALTER TABLE public.users DISABLE TRIGGER ALL;



ALTER TABLE public.users ENABLE TRIGGER ALL;


ALTER TABLE public.bugs DISABLE TRIGGER ALL;



ALTER TABLE public.bugs ENABLE TRIGGER ALL;


ALTER TABLE public.comments DISABLE TRIGGER ALL;



ALTER TABLE public.comments ENABLE TRIGGER ALL;


ALTER TABLE public.run_game_asset_update_jobs DISABLE TRIGGER ALL;



ALTER TABLE public.run_game_asset_update_jobs ENABLE TRIGGER ALL;


ALTER TABLE public.specs DISABLE TRIGGER ALL;

INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('4c315575-c11f-46f6-9afd-1d1e9d304c5c', 62, 8, 'Arcane', 'Manipulates raw Arcane magic, destroying enemies with overwhelming power.

Preferred Weapon: Staff, Wand, Dagger, Sword', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('89fce276-ed25-4ece-b44a-9dc6c1944036', 63, 8, 'Fire', 'Focuses the pure essence of Fire magic, assaulting enemies with combustive flames.

Preferred Weapon: Staff, Wand, Dagger, Sword', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('fd9f21b0-9b12-4a3d-9055-f78f59cd9447', 64, 8, 'Frost', 'Freezes enemies in their tracks and shatters them with Frost magic.

Preferred Weapon: Staff, Wand, Dagger, Sword', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('002329bc-f5f7-4ae4-a621-47be8148f09f', 65, 2, 'Holy', 'Invokes the power of the Light to heal and protect allies and vanquish evil from the darkest corners of the world.

Preferred Weapon: Sword, Mace, and Shield', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('fa24a23d-b2eb-4d84-9331-350f6e952946', 66, 2, 'Protection', 'Uses Holy magic to shield $Ghimself:herself; and defend allies from attackers.

Preferred Weapon: Sword, Mace, Axe, and Shield', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('0725476c-1752-46cc-b471-cfe3217f8081', 70, 2, 'Retribution', 'A righteous crusader who judges and punishes opponents with weapons and Holy magic.

Preferred Weapon: Two-Handed Sword, Mace, Axe', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('c7829aa0-e0bf-4014-8720-33047dd51195', 71, 1, 'Arms', 'A battle-hardened master of weapons, using mobility and overpowering attacks to strike $Ghis:her; opponents down.

Preferred Weapon: Two-Handed Axe, Mace, Sword', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('8cecdf08-3a6f-4f7a-8464-a3aeff23328b', 72, 1, 'Fury', 'A furious berserker unleashing a flurry of attacks to carve $Ghis:her; opponents to pieces.

Preferred Weapons: Dual Axes, Maces, Swords', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('66d1ff5c-4f52-4bd0-ba85-8146b1f11e6a', 73, 1, 'Protection', 'A stalwart protector who uses a shield to safeguard $Ghimself:herself; and $Ghis:her; allies.

Preferred Weapon: Axe, Mace, Sword, and Shield', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('0786092f-092b-4bbd-972b-acdeaa41df1a', 102, 11, 'Balance', 'Can shapeshift into a powerful Moonkin, balancing the power of Arcane and Nature magic to destroy enemies.

Preferred Weapon: Staff, Dagger, Mace', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('46120a25-986c-47e8-9b79-95aefa9c095c', 103, 11, 'Feral', 'Takes on the form of a great cat to deal damage with bleeds and bites.

Preferred Weapon: Staff, Polearm', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('950929c8-110d-49b9-b9fb-5771aaad68b0', 104, 11, 'Guardian', 'Takes on the form of a mighty bear to absorb damage and protect allies.

Preferred Weapon: Staff, Polearm', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('c4e02e35-23d3-42ba-93aa-44c1a91489b0', 105, 11, 'Restoration', 'Channels powerful Nature magic to regenerate and revitalize allies.

Preferred Weapon: Staff, Dagger, Mace', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('e5668352-b4ef-4037-86b0-b051a75b8e77', 250, 6, 'Blood', 'A dark guardian who manipulates and corrupts life energy to sustain $Ghimself:herself; in the face of an enemy onslaught.

Preferred Weapon: Two-Handed Axe, Mace, Sword', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('3a37a1b0-04d5-42b9-8b29-1323ab3fb94a', 251, 6, 'Frost', 'An icy harbinger of doom, channeling runic power and delivering vicious weapon strikes.

Preferred Weapons: Dual Axes, Maces, Swords', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('824e79ea-e562-4ba4-9fbf-3e934b724b7a', 252, 6, 'Unholy', 'A master of death and decay, spreading infection and controlling undead minions to do $Ghis:her; bidding.

Preferred Weapon: Two-Handed Axe, Mace, Sword', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('48502d25-96d8-4c48-b79c-36e2db1c4ef4', 253, 3, 'Beast Mastery', 'A master of the wild who can tame a wide variety of beasts to assist $Ghim:her; in combat.

Preferred Weapon: Bow, Crossbow, Gun', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('5c13a112-7573-4295-b56b-50b6ef98a252', 254, 3, 'Marksmanship', 'A master sharpshooter who excels in bringing down enemies from afar.

Preferred Weapon: Bow, Crossbow, Gun', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('dd97da15-4ac8-44fb-8534-5c309eee9692', 255, 3, 'Survival', 'An adaptive ranger who favors using explosives, animal venom, and coordinated attacks with their bonded beast.

Preferred Weapon: Polearm, Staff', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('866383a8-fbe4-4b70-bbcd-3849f9348e30', 256, 5, 'Discipline', 'Uses magic to shield allies from taking damage as well as heal their wounds.

Preferred Weapon: Staff, Wand, Dagger, Mace', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('12d2ff8a-5cb1-4023-9a83-181c7285155d', 257, 5, 'Holy', 'A versatile healer who can reverse damage on individuals or groups and even heal from beyond the grave.

Preferred Weapon: Staff, Wand, Dagger, Mace', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('10c0f8b8-8593-4e5b-bcd7-2eddb2c8353c', 258, 5, 'Shadow', 'Uses sinister Shadow magic and terrifying Void magic to eradicate enemies.

Preferred Weapon: Staff, Wand, Dagger, Mace', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('ec0d593b-cc3d-49f2-a095-f8441f5c7d57', 259, 4, 'Assassination', 'A deadly master of poisons who dispatches victims with vicious dagger strikes.

Preferred Weapons: Daggers', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('b542a8b0-a357-4226-9ba5-1f4f73dff5ae', 260, 4, 'Outlaw', 'A ruthless fugitive who uses agility and guile to stand toe-to-toe with enemies.

Preferred Weapons: Axes, Maces, Swords, Fist Weapons', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('6b291c26-5a3f-4a60-bfcd-df57a8eb3e96', 261, 4, 'Subtlety', 'A dark stalker who leaps from the shadows to ambush $Ghis:her; unsuspecting prey.

Preferred Weapons: Daggers', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('ac3876d8-00c3-41b0-a934-993061922d5a', 262, 7, 'Elemental', 'A spellcaster who harnesses the destructive forces of nature and the elements.

Preferred Weapon: Mace, Dagger, and Shield', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('a91d090e-7b6f-4495-bab5-611d400d363e', 263, 7, 'Enhancement', 'A totemic warrior who strikes foes with weapons imbued with elemental power.

Preferred Weapons: Dual Axes, Maces, Fist Weapons', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('539c281b-85e1-4733-8aca-e140ba28f98c', 264, 7, 'Restoration', 'A healer who calls upon ancestral spirits and the cleansing power of water to mend allies'' wounds.

Preferred Weapon: Mace, Dagger, and Shield', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('8ec8195b-0335-47cc-83ed-67cf2c8dcee6', 265, 9, 'Affliction', 'A master of shadow magic who specializes in drains and damage-over-time spells.

Preferred Weapon: Staff, Wand, Dagger, Sword', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('a77a3709-b556-44b6-b7ea-a483d853c5f4', 266, 9, 'Demonology', 'A commander of demons who twists the souls of $Ghis:her; army into devastating power.

Preferred Weapon: Staff, Wand, Dagger, Sword', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('a020497f-7350-46a7-9d99-3346748c23cd', 267, 9, 'Destruction', 'A master of chaos who calls down fire to burn and demolish enemies.

Preferred Weapon: Staff, Wand, Dagger, Sword', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('9f11b58d-7203-4762-86fe-ad9b792ea003', 268, 10, 'Brewmaster', 'A sturdy brawler who uses unpredictable movement and mystical brews to avoid damage and protect allies.

Preferred Weapon: Staff, Polearm', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('30bf766a-f59d-47e3-8f2c-b1e5d71489f5', 269, 10, 'Windwalker', 'A martial artist without peer who pummels foes with hands and fists.

Preferred Weapons: Fist Weapons, Axes, Maces, Swords', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('feacae6e-bf3f-4c68-bbcc-d63174d4ff62', 270, 10, 'Mistweaver', 'A healer who masters the mysterious art of manipulating life energies aided by the wisdom of the Jade Serpent.

Preferred Weapon: Staff, Mace, Sword', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('47d7198e-953b-407c-9819-762a0dda6a79', 577, 12, 'Havoc', 'A brooding master of warglaives and the destructive power of Fel magic.

Preferred Weapons: Warglaives, Swords, Axes, Fist Weapons', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('a701b43e-1c7d-48f5-9d03-6ad1d44c0aed', 581, 12, 'Vengeance', 'Embraces the demon within to incinerate enemies and protect their allies.

Preferred Weapons: Warglaives, Swords, Axes, Fist Weapons', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('3b479a6f-884f-4ba9-9be1-84d3f432f14f', 1, 1, 'Warrior', '', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('c06da74a-5ce4-4a0d-85d1-7355493bdaa8', 2, 2, 'Paladin', '', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('7a6a17d0-4ec9-4dce-8c4e-1a3dc9cabcda', 3, 3, 'Hunter', '', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('2f490b46-566e-4dc4-8a5b-ac4663a489f1', 4, 4, 'Rogue', '', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('922d848e-0610-42fd-b338-91bf61bcf198', 5, 5, 'Priest', '', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('517aed9d-a77b-4bbf-b5e6-53fafba3dd8f', 6, 6, 'Death Knight', '', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('805e41a6-680a-4bb4-9f0e-198018e49361', 7, 7, 'Shaman', '', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('1ad68dd0-8609-467e-acc6-6647e0286916', 8, 8, 'Mage', '', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('1e21e34d-6f0a-4d5d-9b9f-356ffb6037a6', 9, 9, 'Warlock', '', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('47dae6d1-9d11-4a66-a53a-622bf33bb130', 10, 10, 'Monk', '', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('f2ff1b22-09a4-4644-9884-e91b60171ce3', 11, 11, 'Druid', '', '');
INSERT INTO public.specs (id, game_id, game_class_id, spec_name, spec_description, spec_icon) VALUES ('089cbb79-1258-41f9-9721-b64eaec78c81', 12, 12, 'Demon Hunter', '', '');


ALTER TABLE public.specs ENABLE TRIGGER ALL;


